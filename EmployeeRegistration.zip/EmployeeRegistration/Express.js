const express = require("express")
const app = express()
const port = 3001
const bodyParser = require("body-parser");
const methodOverride = require('method-override');
const path=require('path');
const db = require("./models/db")
 
// create application/x-www-form-urlencoded parser
app.use(bodyParser.urlencoded({ extended:true }));

// parse application/json
app.use(bodyParser.json());

//connect the views folder
app.set('views',path.join(__dirname,'views'))

//view engine
app.set('view engine','ejs');

app.use(methodOverride('_method'));

const employeeRouter = require("./routes/employee.js")
const homeRouter = require("./routes/home.js")

app.use("/",homeRouter);
app.use('/',employeeRouter);


app.listen(port,console.log(`port implemented is ${port}`));