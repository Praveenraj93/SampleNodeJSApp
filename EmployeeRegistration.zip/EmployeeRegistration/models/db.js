const mysql  = require('mysql');

let pool  = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'Employee'
});

module.exports.executeQuery = (query,data) => { return new Promise((resolve,reject) =>{
    pool.getConnection(function(err, connection) {
        connection.query(query,data,function(err,rows){
            connection.release();
            if (err) return reject(err);
            resolve(rows);
        });
    });
});
}
