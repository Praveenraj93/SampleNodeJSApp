const express = require("express")
const router = express.Router();
const db = require("../models/db");

router.use( function( req, res, next ) {
    if ( req.query._method == 'DELETE' ) {
        req.method = 'DELETE';
        req.url = req.path;
    }   
    next(); 
});

router.get('/Employee/EmployeeRegister',(req,res)=>{
   
    res.render("employee.ejs",{data:1})
})

router.get('/Employee/EmployeeSearch',(req,res)=>{
   
    res.render("showSearch.ejs",{data:0})
})

router.get('/Employee/SearchWithID',(req,res)=>{
   
    var Query = "select * from Employee where eid = ?";
    var data=req.query.eid;
    db.executeQuery(Query,[data])
        .then((result)=> res.render('showSearch',{data:result}))
        .catch((err)=> res.send(err));
})

router.get('/Employee/RedirectToSearch/:eid',(req,res)=>{
   
    var Query = "select * from Employee where eid = ?";
    var data=req.params.eid;
    db.executeQuery(Query,[data])
        .then((result)=> res.render('showSearch',{data:result}))
        .catch((err)=> res.send(err));
})

router.get('/Employee/EmployeeSearch/Edit/:eid',(req,res) => {
    var Query = "select * from Employee where eid = ?";
    var data=req.params.eid;
    db.executeQuery(Query,[data])
        .then((result)=> res.render('SearchEmployeeEditOrDelete',{put: true,data:result}))
        .catch((err)=> res.send(err));
})

router.put('/Employee/EmployeeSearch/Update/:eid',(req,res) => {
    var Query = "update Employee set ? where eid = '"+req.params.eid+"'";
    var data ={efname: req.body.efname,
        emname: req.body.emname,
        elname: req.body.elname,
        eid : req.params.eid,
        edesig : req.body.edesig,
        eloc : req.body.eloc,
        eskil : req.body.eskil}

    db.executeQuery(Query,data)
        .then((result)=> res.redirect('/Employee/RedirectToSearch/'+req.params.eid))
        .catch((err)=> res.send(err));
})

router.get('/Employee/EmployeeList',(req,res)=>{
   
    var Query = "select * from Employee;"
    var data={};
    db.executeQuery(Query,data)
        .then((result)=> res.render('employeeList',{data:result}))
        .catch((err)=> res.send(err));
})

router.post('/Employee/Add',(req,res)=>{
    var data ={efname: req.body.efname,
                emname: req.body.emname,
                elname: req.body.elname,
                eid : req.body.eid,
                edesig : req.body.edesig,
                eloc : req.body.eloc,
                eskil : req.body.eskil}
    
    var Query ="insert into Employee set ?";

    db.executeQuery(Query,data)
        .then((result)=> res.render('employee',{data:result,eid:req.body.eid}))
        .catch((err)=> res.send(err));
})

router.get('/Employee/EmployeeEdit/:eid',(req,res) => {
    var Query = "select * from Employee where eid = ?";
    var data=req.params.eid;
    db.executeQuery(Query,[data])
        .then((result)=> res.render('EditEmployee',{put: true,data:result}))
        .catch((err)=> res.send(err));
})

router.put('/Employee/EmployeeEdit/Update/:eid',(req,res) => {
    var Query = "update Employee set ? where eid = '"+req.params.eid+"'";
    var data ={efname: req.body.efname,
        emname: req.body.emname,
        elname: req.body.elname,
        eid : req.params.eid,
        edesig : req.body.edesig,
        eloc : req.body.eloc,
        eskil : req.body.eskil}

    db.executeQuery(Query,data)
        .then((result)=> res.redirect('/Employee/EmployeeList/'))
        .catch((err)=> res.send(err));
})
router.delete('/Employee/EmployeeEdit/Delete/:eid',(req,res)=>{
    var Query = "Delete from Employee where eid = ?";
    var data=req.params.eid;
    db.executeQuery(Query,[data])
        .then((result)=> res.render('DeleteEmployee',{put: true,eid:req.params.eid}))
        .catch((err)=> res.send(err));
})


module.exports = router;